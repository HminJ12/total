$(function(){/* ex1 */

})/* ex1 end */

$(function(){/* ex2 */

})/* ex2 end */


$(function(){/* ex3 */

})/* ex3 end */


$(function(){/* ex4 */

})/* ex4 end */


$(function(){/* ex5 */

})/* ex5 end */